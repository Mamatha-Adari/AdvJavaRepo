package studentpkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BatchUpdatesStudent {
	Connection con;
	PreparedStatement psmt;
	Statement stmt;
	public void createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb","root","svecw@123");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void batchInsertSt() {
		try {
			String query="Insert into student values(?,?,?,?)";
			psmt=con.prepareStatement(query);
			ArrayList<String> stdnt=new ArrayList<String>();
			
			stdnt.add("1200,Mamatha,IT,5");
			stdnt.add("124B,Bhargavi,ECE,7");
			for(String std:stdnt) {
				String columns[]= std.split(",");
				psmt.setString(1,columns[0]);
				psmt.setString(2, columns[1]);
				psmt.setString(3, columns[2]);
				psmt.setString(4, columns[3]);
				psmt.addBatch();
			}
			int rows[]=psmt.executeBatch();
			System.out.println(rows.length+" "+"Insertions done");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void batchSelectSt() {
		try {
			String query="select * from student";
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			while(rs.next()) {
				System.out.println("regd No:"+rs.getString(1));
				System.out.println("Name of the Student:"+rs.getString(2));
				System.out.println("Branch:"+rs.getString(3));
				System.out.println("Studying Semester:"+rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
