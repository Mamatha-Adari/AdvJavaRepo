package studentpkg;

public class BatchUpdatesStudentDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BatchUpdatesStudent bu=new BatchUpdatesStudent();
		bu.createConnection();
		bu.batchInsertSt();
		bu.batchSelectSt();

	}

}
