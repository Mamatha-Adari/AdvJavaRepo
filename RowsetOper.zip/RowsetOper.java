package studentpkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

public class RowsetOper {
	Connection con;
	public void rowsetOperations() {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb","root","svecw@123");
				CachedRowSet crs=RowSetProvider.newFactory().createCachedRowSet();
				con.setAutoCommit(false);
				crs.setUrl("jdbc:mysql://localhost:3306/studentdb");
				crs.setUsername("root");
				crs.setPassword("svecw@123");
				crs.setCommand("select * from student");
				crs.execute();
				while(crs.next()) {
					System.out.println("Regdno:"+crs.getString(1));
					System.out.println("Name:"+crs.getString(2));
					System.out.println("Branch:"+crs.getString(3));
					System.out.println("Semester:"+crs.getInt(4));
				}
				crs.first();
				crs.absolute(3);
				System.out.println("3rd row");
				System.out.println("Regdno:"+crs.getString(1));
				System.out.println("Name:"+crs.getString(2));
				System.out.println("Branch:"+crs.getString(3));
				System.out.println("Semester:"+crs.getInt(4));
				crs.absolute(4);
				crs.updateString("name", "nissy");
				crs.updateRow();
				crs.moveToInsertRow();
				crs.updateString(1,"1AB2");
				crs.updateString(2, "thanu");
				crs.updateString(3,"ML");
				crs.updateInt(4, 3);
				crs.insertRow();
//				crs.acceptChanges(con);
				crs.close();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

}
