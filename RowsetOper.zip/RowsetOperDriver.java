package studentpkg;

public class RowsetOperDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RowsetOper rws=new RowsetOper();
		rws.rowsetOperations();
		
	}

}
