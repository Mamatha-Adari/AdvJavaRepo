package studentpkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ScrollUpdateSt {
	Connection con;
	Statement stmt;
	public void createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb","root","svecw@123");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void scrollUpdateRs() {
		String query="select * from student";
		try {
			stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=stmt.executeQuery(query);
			rs.afterLast();
			while(rs.previous()) {
				if(rs.getString(1).equals("1209")) {
					rs.updateString(2,"thanu" );
					rs.updateRow();
				}
			
			System.out.println("RegdNo:"+rs.getString(1));
			System.out.println("Name:"+rs.getString(2));
			System.out.println("Branch:"+rs.getString(3));
			System.out.println("semester:"+rs.getString(4));
			rs.absolute(6);
			System.out.println("RegdNo:"+rs.getString(1));
			System.out.println("Name:"+rs.getString(2));
			System.out.println("Branch:"+rs.getString(3));
			System.out.println("Semester:"+rs.getString(4));
			rs.relative(2);
			System.out.println("RegdNo:"+rs.getString(1));
			System.out.println("Name:"+rs.getString(2));
			System.out.println("Branch:"+rs.getString(3));
			System.out.println("Semester:"+rs.getString(4));
			rs.moveToInsertRow();
			rs.updateString(1,"A1B2");
			rs.updateString(2, "jasshu");
			rs.updateString(3,"AIML");
			rs.updateString(4, "2");
			rs.first();
			rs.deleteRow();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
