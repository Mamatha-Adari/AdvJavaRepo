package studentpkg;

public class ScrollUpdateStDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ScrollUpdateSt su=new ScrollUpdateSt();
		su.createConnection();
		su.scrollUpdateRs();
	}

}
