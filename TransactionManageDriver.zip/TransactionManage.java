package studentpkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TransactionManage {
	Connection con;
	PreparedStatement psmt;
	public void createConnection() {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb","root","svecw@123");
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	public void studentDet(String regdno,String name,String branch,int sem) {
		try {
			String squery="update student set sem=? where regdno=?";
			con.setAutoCommit(false);
			PreparedStatement spsmt=con.prepareStatement(squery);
			spsmt.setInt(1,sem);
			spsmt.setString(2,regdno);
			spsmt.executeUpdate();
			String equery="select * from student where regdno=?";
			PreparedStatement epsmt=con.prepareStatement(equery);
			epsmt.setString(1,regdno);
			ResultSet rs=epsmt.executeQuery();
			if(rs.next()) {
				int semt=rs.getInt(4);
				if(semt>8) {
					con.rollback();
					System.out.println("Not a valid semester");
					return;
				}
				System.out.println("Valid semester");
				System.out.println("Registration Number:"+rs.getString(1));
				System.out.println("Name:"+rs.getString(2));
				System.out.println("Branch:"+rs.getString(3));
				System.out.println("Semster:"+rs.getInt(4));
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
