package studentpkg;

public class TransactionManageDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TransactionManage tm=new TransactionManage();
		tm.createConnection();
		tm.studentDet("12A0","Mamatha","IT",9);
	}

}
